package model;

public interface Discountable {
    public double getDiscount();
}
