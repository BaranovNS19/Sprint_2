package model.constants;



public class Discount {

    public static final int DISCOUNT = 60;






}
